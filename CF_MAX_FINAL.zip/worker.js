import { Container, getContainer } from "@cloudflare/containers";

export class MaxBotContainer extends Container {
  defaultPort = 3000;
  sleepAfter = "10m";
  envVars = {
    MAX_BOT_TOKEN: this.env.MAX_BOT_TOKEN,
    OPENAI_API_KEY: this.env.OPENAI_API_KEY,
    OPENAI_MODEL: this.env.OPENAI_MODEL || "gpt-5.6-terra",
    PORT: "3000",
  };
}

async function wakeBot(env) {
  const container = getContainer(env.MAX_BOT_CONTAINER, "main");
  const response = await container.fetch(new Request("http://container/health"));
  await response.arrayBuffer();
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/" || url.pathname === "/health" || url.pathname === "/start") {
      try {
        const container = getContainer(env.MAX_BOT_CONTAINER, "main");
        const response = await container.fetch(new Request("http://container/health"));
        const text = await response.text();
        return new Response(text || "MAX bot container is running\n", {
          status: response.status,
          headers: { "content-type": "text/plain; charset=utf-8" },
        });
      } catch (error) {
        console.error("Container start error", error);
        return new Response(`Container error: ${error?.message || error}`, { status: 500 });
      }
    }

    return new Response("Not found", { status: 404 });
  },

  async scheduled(_controller, env, ctx) {
    ctx.waitUntil(
      wakeBot(env).catch((error) => console.error("Keepalive error", error)),
    );
  },
};
